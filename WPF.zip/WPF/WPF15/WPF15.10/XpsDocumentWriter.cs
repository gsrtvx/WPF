﻿using System;
using System.Windows.Documents;

namespace WPF15._10
{
    internal class XpsDocumentWriter
    {
        internal void Write(FixedDocument fixedDocument)
        {
            throw new NotImplementedException();
        }
    }
}